
Data for 2D environments of different sizes. Each directory contains obstacle maps (inputs.dat), start-point maps (s_maps.dat), goal-point maps (g_maps.dat), and path maps (outputs.dat). Note that there are no start-point maps  and goal-point maps  for the multi case, and there are three outputs maps where each of them correspond to the path maps from different sources.

Each data file contains 30.000 rows where each row corresponds to one environment. One environment is encoded with k = n x n digits, where n is the size of the environment.
 